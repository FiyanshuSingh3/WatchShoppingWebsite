/*=============== SHOW MENU ===============*/
const navMenu = document.getElementById('nav-menu'),
      navToggle = document.getElementById('nav-toggle'),
      navClose = document.getElementById('nav-close')

/* Menu show */
if(navToggle){
    navToggle.addEventListener('click', () =>{
        navMenu.classList.add('show-menu')
    })
}

/* Menu hidden */
if(navClose){
    navClose.addEventListener('click', () =>{
        navMenu.classList.remove('show-menu')
    })
}

/*=============== REMOVE MENU MOBILE ===============*/
const navLink = document.querySelectorAll('.nav__link')

const linkAction = () =>{
    const navMenu = document.getElementById('nav-menu')
    // When we click on each nav__link, we remove the show-menu class
    navMenu.classList.remove('show-menu')
}
navLink.forEach(n => n.addEventListener('click', linkAction))

/*=============== CHANGE BACKGROUND HEADER ===============*/
const scrollHeader = () =>{
    const header = document.getElementById('header')
    // Add a class if the bottom offset is greater than 50 of the viewport
    this.scrollY >= 50 ? header.classList.add('scroll-header') 
                       : header.classList.remove('scroll-header')
}
window.addEventListener('scroll', scrollHeader)

/*=============== TESTIMONIAL SWIPER ===============*/
let testimonialSwiper = new Swiper(".testimonial-swiper", {
    spaceBetween: 30,
    loop: 'true',

    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});

/*=============== NEW SWIPER ===============*/
let newSwiper = new Swiper(".new-swiper", {
    spaceBetween: 24,
    loop: 'true',

    breakpoints: {
        576: {
          slidesPerView: 2,
        },
        768: {
          slidesPerView: 3,
        },
        1024: {
          slidesPerView: 4,
        },
    },
});

/*=============== SCROLL SECTIONS ACTIVE LINK ===============*/
const sections = document.querySelectorAll('section[id]')
    
const scrollActive = () =>{
  	const scrollDown = window.scrollY

	sections.forEach(current =>{
		const sectionHeight = current.offsetHeight,
			  sectionTop = current.offsetTop - 58,
			  sectionId = current.getAttribute('id'),
			  sectionsClass = document.querySelector('.nav__menu a[href*=' + sectionId + ']')

		if(scrollDown > sectionTop && scrollDown <= sectionTop + sectionHeight){
			sectionsClass.classList.add('active-link')
		}else{
			sectionsClass.classList.remove('active-link')
		}                                                    
	})
}
window.addEventListener('scroll', scrollActive)

/*=============== SHOW SCROLL UP ===============*/ 
const scrollUp = () =>{
	const scrollUp = document.getElementById('scroll-up')
    // When the scroll is higher than 350 viewport height, add the show-scroll class to the a tag with the scrollup class
	this.scrollY >= 350 ? scrollUp.classList.add('show-scroll')
						: scrollUp.classList.remove('show-scroll')
}
window.addEventListener('scroll', scrollUp)

/*=============== CART FUNCTIONALITY ===============*/
let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

const cart = document.getElementById('cart'),
      cartShop = document.getElementById('cart-shop'),
      cartClose = document.getElementById('cart-close'),
      cartContainer = document.querySelector('.cart__container'),
      cartEmpty = document.querySelector('.cart__empty'),
      cartBadge = document.querySelector('.cart__badge'),
      cartCheckoutBtn = document.querySelector('.cart__checkout');

// Create cart badge if it doesn't exist
if (cartShop && !cartBadge) {
    const badge = document.createElement('span');
    badge.classList.add('cart__badge');
    badge.id = 'cart-badge';
    cartShop.appendChild(badge);
}

// Initialize cart
function initCart() {
    updateCartUI();
    updateCartBadge();
}

// Update cart UI
function updateCartUI() {
    if (!cartContainer) return;
    
    if (cartItems.length === 0) {
        cartContainer.innerHTML = '';
        if (cartEmpty) cartEmpty.classList.add('show');
        if (cartCheckoutBtn) cartCheckoutBtn.style.display = 'none';
    } else {
        if (cartEmpty) cartEmpty.classList.remove('show');
        if (cartCheckoutBtn) cartCheckoutBtn.style.display = 'block';
        
        cartContainer.innerHTML = cartItems.map((item, index) => `
            <article class="cart__card" data-id="${index}">
                <div class="cart__box">
                    <img src="${item.img}" alt="" class="cart__img">
                </div>
                <div class="cart__details">
                    <h3 class="cart__title">${item.name}</h3>
                    <span class="cart__price">₹${item.price}</span>
                    <div class="cart__amount">
                        <div class="cart__amount-content">
                            <span class="cart__amount-box" onclick="updateQuantity(${index}, -1)">
                                <i class='bx bx-minus'></i>
                            </span>
                            <span class="cart__amount-number">${item.quantity}</span>
                            <span class="cart__amount-box" onclick="updateQuantity(${index}, 1)">
                                <i class='bx bx-plus'></i>
                            </span>
                        </div>
                        <i class='bx bx-trash-alt cart__amount-trash' onclick="removeFromCart(${index})"></i>
                    </div>
                </div>
            </article>
        `).join('');
    }
    
    updateTotal();
}

// Update cart badge
function updateCartBadge() {
    const badge = document.getElementById('cart-badge');
    if (badge) {
        const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
        if (totalItems > 0) {
            badge.textContent = totalItems;
            badge.classList.add('show');
        } else {
            badge.classList.remove('show');
        }
    }
}

// Add to cart
function addToCart(name, price, img) {
    const existingItem = cartItems.find(item => item.name === name);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cartItems.push({
            name,
            price: parseFloat(price.replace(/[₹$]/g, '')),
            img,
            quantity: 1
        });
    }
    
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartUI();
    updateCartBadge();
    
    // Show cart on mobile
    if (window.innerWidth < 768) {
        cart.classList.add('show-cart');
    }
}

// Remove from cart
function removeFromCart(index) {
    cartItems.splice(index, 1);
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartUI();
    updateCartBadge();
}

// Update quantity
function updateQuantity(index, change) {
    cartItems[index].quantity += change;
    
    if (cartItems[index].quantity <= 0) {
        removeFromCart(index);
    } else {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartUI();
        updateCartBadge();
    }
}

// Update total price
function updateTotal() {
    const cartPrices = document.querySelector('.cart__prices');
    if (!cartPrices) return;
    
    const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    cartPrices.innerHTML = `
        <span class="cart__prices-item">${totalItems} items</span>
        <span class="cart__prices-total">₹${totalPrice.toFixed(2)}</span>
    `;
}

// Checkout button
if (cartCheckoutBtn) {
    cartCheckoutBtn.addEventListener('click', () => {
        if (cartItems.length > 0) {
            window.location.href = 'checkout.html';
        }
    });
}

// Initialize cart on page load
initCart();

/*===== CART SHOW =====*/
if(cartShop){
    cartShop.addEventListener('click', () =>{
        cart.classList.add('show-cart')
    })
}

/*===== CART HIDDEN =====*/
if(cartClose){
    cartClose.addEventListener('click', () =>{
        cart.classList.remove('show-cart')
    })
}

/*=============== DARK LIGHT THEME ===============*/ 
const themeButton = document.getElementById('theme-button')
const darkTheme = 'dark-theme'
const iconTheme = 'bx-sun'

// Previously selected topic (if user selected)
const selectedTheme = localStorage.getItem('selected-theme')
const selectedIcon = localStorage.getItem('selected-icon')

// We obtain the current theme that the interface has by validating the dark-theme class
const getCurrentTheme = () => document.body.classList.contains(darkTheme) ? 'dark' : 'light'
const getCurrentIcon = () => themeButton.classList.contains(iconTheme) ? 'bx bx-moon' : 'bx bx-sun'

// We validate if the user previously chose a topic
if (selectedTheme) {
  // If the validation is fulfilled, we ask what the issue was to know if we activated or deactivated the dark
  document.body.classList[selectedTheme === 'dark' ? 'add' : 'remove'](darkTheme)
  themeButton.classList[selectedIcon === 'bx bx-moon' ? 'add' : 'remove'](iconTheme)
}

// Activate / deactivate the theme manually with the button
themeButton.addEventListener('click', () => {
    // Add or remove the dark / icon theme
    document.body.classList.toggle(darkTheme)
    themeButton.classList.toggle(iconTheme)
    // We save the theme and the current icon that the user chose
    localStorage.setItem('selected-theme', getCurrentTheme())
    localStorage.setItem('selected-icon', getCurrentIcon())
})
