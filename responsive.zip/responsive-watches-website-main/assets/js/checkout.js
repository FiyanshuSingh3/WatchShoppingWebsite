// Checkout functionality
document.addEventListener('DOMContentLoaded', function() {
    // Get cart items from localStorage
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const checkoutItems = document.getElementById('checkout-items');
    const checkoutSubtotal = document.getElementById('checkout-subtotal');
    const checkoutTotal = document.getElementById('checkout-total');
    const checkoutSuccess = document.getElementById('checkout-success');
    const checkoutForm = document.getElementById('checkout-form');

    // If no items in cart, redirect to home
    if (cartItems.length === 0) {
        window.location.href = 'index.html';
        return;
    }

    // Display cart items
    function displayItems() {
        checkoutItems.innerHTML = cartItems.map(item => `
            <div class="checkout__product">
                <img src="${item.img}" alt="${item.name}" class="checkout__product-img">
                <div class="checkout__product-info">
                    <div class="checkout__product-name">${item.name}</div>
                    <div class="checkout__product-price">₹${item.price} x ${item.quantity}</div>
                </div>
                <div style="font-weight: var(--font-bold);">
                    ₹${(item.price * item.quantity).toFixed(2)}
                </div>
            </div>
        `).join('');

        // Calculate totals
        const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const shipping = 10;
        const total = subtotal + shipping;

        checkoutSubtotal.textContent = `₹${subtotal.toFixed(2)}`;
        checkoutTotal.textContent = `₹${total.toFixed(2)}`;
    }

    displayItems();

    // Handle place order
    window.placeOrder = function() {
        // Validate forms
        const shippingForm = document.getElementById('shipping-form');
        const paymentForm = document.getElementById('payment-form');

        if (!shippingForm.checkValidity() || !paymentForm.checkValidity()) {
            alert('Please fill in all required fields');
            return;
        }

        // Show success message
        checkoutForm.style.display = 'none';
        checkoutSuccess.classList.add('show');

        // Clear cart
        localStorage.removeItem('cartItems');

        // Update cart badge
        const badge = document.getElementById('cart-badge');
        if (badge) {
            badge.classList.remove('show');
        }
    };
});

